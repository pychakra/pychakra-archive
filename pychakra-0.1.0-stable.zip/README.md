# PyChakra

## About :

PyChakra is an open-source Python-based HTTP WSGI server.
The goal is to create a configurable, manageable, easy-to-use,
and lightweight Python-based HTTP WSGI server.

## License :

PyChakra is open-source, 
licensed in [GNU Public License 3 / GPL 3](https://www.gnu.org/licenses/gpl-3.0.en.html)

## More info :

[Click here ](https://pychakra.github.io) to visit our website.
