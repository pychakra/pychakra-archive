# Notes

The development status is still on early stages.

There are no advanced features, like in Gunicorn.

More features coming soon !